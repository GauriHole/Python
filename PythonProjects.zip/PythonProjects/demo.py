print("My Name is Gauri , I am Most Beautiful in the World")
