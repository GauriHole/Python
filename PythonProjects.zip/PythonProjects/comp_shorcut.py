something = False

if something:
    print(" This is True Section Baby ...")
else:
    print(" This is False Section Babu ...")