# Variables are the small piece of memory...
name = "Gauri Hole"
course = "Python 101"
print(f"Hello {name} , Welcome to",course)