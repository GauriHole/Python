age = 31
name = "Gauri Hole"

if age >= 18 and name=="Gauri_Hole":
    print("\t \t Your Step towards the Success Is Starts !")
else:
    print("\t \t Your Age for Study Now !")