sets = {"Item 1","Item 2","Item 2","Item 3"}
print(sets)
sets.add("Item 4")
print(sets)
sets.remove("Item 2")
print(sets)
