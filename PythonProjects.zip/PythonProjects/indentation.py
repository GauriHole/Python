course = "Python 101"
twitter = "@GauriHole"

if twitter == "@GauriHole":
    name = "Gauri Hole"
    instagram = "@hole_gauri_r"
print(f"\n \n Hello {name} Your Instagram Account is Changed from {twitter} ... \n ")
print(f"          * * * *    Login to Your Account As {instagram}    * * * *    ")