sentenc = """ A Sentence in here And on a new line """
print(sentenc)
print(sentenc.lower())
print(sentenc.upper())
