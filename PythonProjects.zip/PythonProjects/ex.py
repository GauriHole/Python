print("Hello Everyone  \n             ...... Welcome to Python Programming ....")
str=(input("Enter Username : \n "))
strpsd=(input(" Enter Password : "))
if str=="Gauri":
    print("Hello "+str)
else if strpsd=="admin123":
    print("")
else:
    print("Wrong Username , try again ! ");
