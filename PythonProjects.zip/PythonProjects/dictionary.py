Person = {
    "Id" : "G-12345",
    "Name" : "Gauri Hole",
    "Instagram" : "@hole_gauri_r",
    "Email" : "gaurihole@gmail.com",
    "Fav Hero" : "Ajinkya Raut"
}
print(Person)
Person['Instagram']="@thoughts_of_gauri"
print(Person)