animals = ["Cat","Dog","Zebra","Aardvaark"]
print(animals)
animals.sort()
print(animals)
for item in animals:
    print("The Annimal Name is : ",animals)
