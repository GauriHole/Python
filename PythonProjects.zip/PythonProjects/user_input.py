name = input("what is your name ? ")
age = input("how old are you ?")
dog_age = int(age) * 4
print(f" \t\t My Self {name} ,\t I am {age} Years Old . My Dog Age is {dog_age} \n \t\t That's all , Thank You !")