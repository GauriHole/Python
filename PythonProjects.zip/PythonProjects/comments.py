# This code is all about comments , this hash symbol is used for  Single line comment
print(" This is Single Line Comment ^ ")
