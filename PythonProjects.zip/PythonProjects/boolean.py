can_code = False
if can_code == True:
    print(" Ooooo , You Really Code ")
else:
    print(" You Need To Work on Your Code ")