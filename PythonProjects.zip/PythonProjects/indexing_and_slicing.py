lst = [1,2,3,4,5]
print(lst)
print(lst[0:3])
print(lst[2::])

print(" Reverse of List : ",lst[::-1])