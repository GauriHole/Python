wallet = None
if wallet == None:
    print("There is nothing in My Wallet ")
    wallet = 82.45
print("Now Your Wallet amount is :",wallet)