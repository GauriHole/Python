name = "Gauri Hole"

# Type - 01
welcome_msg = "Hello {} welcome to Python 101".format(name)
print(welcome_msg)

# Type - 02
welcome_msg2 = f"\t I am really serious about chocalates that's why i called {name} ,\n \t \t  Thank You !"
print(welcome_msg2)