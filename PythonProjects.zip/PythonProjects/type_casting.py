grocery_list = ['Apples','Orange','Banana','Pineapple']
grocery_list =set(grocery_list)
print(grocery_list)
print(type(grocery_list))
#Assignment
grocery_list =tuple(grocery_list)
print(grocery_list)
print(type(grocery_list))
