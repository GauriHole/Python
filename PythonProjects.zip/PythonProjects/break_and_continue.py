items = ['One','Two','Three','Four','Five']

for item in items:
    if item == 'Two' or  item == 'Four':
        continue
    print(item)