items = 4
price = 19.97
total = items * price
print(total)
total = "19.97" * items
print(total)
word = "Na"
print(word + 10)
